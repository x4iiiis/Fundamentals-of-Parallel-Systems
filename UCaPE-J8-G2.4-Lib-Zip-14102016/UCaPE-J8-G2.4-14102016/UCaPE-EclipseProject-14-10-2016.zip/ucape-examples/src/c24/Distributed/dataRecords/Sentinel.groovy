package c24.Distributed.dataRecords

import java.io.Serializable;

class Sentinel implements Serializable {
  int sentinel = 0
}
