package c24.Distributed.loaderObjects








class Sentinel implements Serializable {
	def sentinel = -1
}
