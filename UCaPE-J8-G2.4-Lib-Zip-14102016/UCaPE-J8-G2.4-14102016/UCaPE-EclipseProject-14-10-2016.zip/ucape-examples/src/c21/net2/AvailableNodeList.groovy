package c21.net2








class AvailableNodeList implements Serializable{

  def anl  // a list of available nodes

}
