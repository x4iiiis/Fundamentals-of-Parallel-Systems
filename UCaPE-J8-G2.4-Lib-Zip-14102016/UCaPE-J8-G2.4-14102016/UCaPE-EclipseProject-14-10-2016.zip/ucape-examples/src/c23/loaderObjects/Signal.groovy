package c23.loaderObjects








class Signal implements Serializable {
	def signal = -1
}
