package c23.loaderObjects








class Sentinel implements Serializable {
	def sentinel = -1
}
