package c16.net2
 
// copyright 2012-13 Jon Kerridge
// Let's Do It In Parallel





class Printline implements Serializable {  
	
  def int printKey
  def String line  
}
