package c19.net2.groupLocationService

import org.jcsp.net2.*






class GLdata implements Serializable{
	
	def NetChannelLocation responseLocation
	def groupName
	def location

}
