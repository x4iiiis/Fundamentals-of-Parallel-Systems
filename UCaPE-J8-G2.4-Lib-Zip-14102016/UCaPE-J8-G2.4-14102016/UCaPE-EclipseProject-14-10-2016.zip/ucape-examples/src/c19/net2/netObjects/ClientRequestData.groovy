package c19.net2.netObjects








class ClientRequestData  implements Serializable {
	
	def processReceiveLocation
	def serviceRequired
}
