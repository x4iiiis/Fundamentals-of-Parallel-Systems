package c22.emitter;

import org.jcsp.lang.*

interface CopyOfManipulateInterface extends Serializable {
	
	abstract manipulate(id)
	abstract display(now)
}
