package c22.universalClasses








class InitObject implements Serializable {
	def id = 0
	def channelAddress = null
}
