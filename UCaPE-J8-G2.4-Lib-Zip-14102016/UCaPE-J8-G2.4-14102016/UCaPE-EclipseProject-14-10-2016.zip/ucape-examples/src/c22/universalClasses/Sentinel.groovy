package c22.universalClasses;








class Sentinel implements Serializable{
	def sentinel = 0
}
