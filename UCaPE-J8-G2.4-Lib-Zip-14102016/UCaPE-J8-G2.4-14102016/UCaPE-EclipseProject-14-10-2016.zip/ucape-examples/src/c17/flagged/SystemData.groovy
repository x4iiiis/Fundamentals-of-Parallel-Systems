package c17.flagged

// copyright 2012-13 Jon Kerridge
// Let's Do It In Parallel





class SystemData {
	
  def a
  def b
  def c  
  
  def String toString() {
    String s
    s = "System Data: [" + a + ", " + b + ", " + c + "]"
    return s
  }
}
