package c25

class GetGameDetails implements Serializable {
	int id
}
