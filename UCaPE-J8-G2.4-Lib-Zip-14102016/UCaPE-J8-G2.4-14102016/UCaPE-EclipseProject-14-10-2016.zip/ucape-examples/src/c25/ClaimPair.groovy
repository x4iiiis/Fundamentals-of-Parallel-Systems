package c25

class ClaimPair implements Serializable {
	def gameId
	def id
	def p1
	def p2
}
