package c25

class WithdrawFromGame implements Serializable {
	def id
}
