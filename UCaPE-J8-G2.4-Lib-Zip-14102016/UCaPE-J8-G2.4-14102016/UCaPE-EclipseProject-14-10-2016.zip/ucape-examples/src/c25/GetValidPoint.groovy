package c25

class GetValidPoint  implements Serializable {
	def side
	def gap
	def pairsMap
}
