package c25

class MousePoint implements Serializable {
	def point = []
}
